import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery, useAction, updateDeliveryStatus } from 'wasp/client/operations';

const OrderPage = () => {
  const { orderId } = useParams();
  const { data: order, isLoading, error } = useQuery(getOrders); // Fixing the query to use getOrders
  const updateDeliveryStatusFn = useAction(updateDeliveryStatus);
  const [newStatus, setNewStatus] = useState('');

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleUpdateStatus = () => {
    updateDeliveryStatusFn({ id: orderId, status: newStatus }); // Fixing the action call to include id and status
    setNewStatus('');
  };

  return (
    <div className='p-4'>
      <div>{order.drug}</div>
      <div>{order.quantity}</div>
      <div>{order.deliveryStatus}</div>
      <input
        type='text'
        placeholder='New Delivery Status'
        className='px-1 py-2 border rounded text-lg'
        value={newStatus}
        onChange={(e) => setNewStatus(e.target.value)}
      />
      <button
        onClick={handleUpdateStatus}
        className='bg-blue-500 hover:bg-blue-700 px-2 py-2 text-white font-bold rounded'
      >
        Update Status
      </button>
    </div>
  );
}

export default OrderPage;