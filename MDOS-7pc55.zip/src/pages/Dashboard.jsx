import React from 'react';
import { useQuery, useAction, Link } from 'wasp/client/operations';

const DashboardPage = () => {
  const { data: drugs, isLoading: drugsLoading, error: drugsError } = useQuery(getDrugs);
  const { data: orders, isLoading: ordersLoading, error: ordersError } = useQuery(getOrders);
  const createOrderFn = useAction(createOrder);

  if (drugsLoading || ordersLoading) return 'Loading...';
  if (drugsError || ordersError) return 'Error: ' + drugsError + ordersError;

  const handleCreateOrder = (drugName, quantity) => {
    createOrderFn({ drug: drugName, quantity: quantity });
  };

  return (
    <div className='p-4'>
      <h1 className='text-3xl font-bold mb-6'>Dashboard</h1>
      <div className='mb-6'>
        <h2 className='text-xl font-bold mb-2'>Drug List:</h2>
        <ul>
          {drugs.map((drug) => (
            <li key={drug.id} className='mb-2'>
              {drug.name} - Prescription: {drug.isPrescribed ? 'Required' : 'Not required'}
            </li>
          ))}
        </ul>
      </div>
      <div>
        <h2 className='text-xl font-bold mb-2'>Your Orders:</h2>
        <ul>
          {orders.map((order) => (
            <li key={order.id} className='mb-4 bg-gray-100 p-4 rounded-lg'>
              <div>Drug: {order.drug} - Quantity: {order.quantity}</div>
              <div>Status: {order.deliveryStatus}</div>
              <button
                onClick={() => handleCreateOrder(order.drug, order.quantity + 1)}
                className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-2'
              >
                Reorder
              </button>
              <Link
                to={`/order/${order.id}`}
                className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded ml-2'
              >
                Details
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default DashboardPage;