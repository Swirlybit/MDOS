import { HttpError } from 'wasp/server'

export const getDrugs = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.Drug.findMany();
}

export const getOrders = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.Order.findMany({
    where: { userId: context.user.id },
    include: { user: true }
  });
}