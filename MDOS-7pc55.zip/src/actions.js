import { HttpError } from 'wasp/server'

export const createOrder = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const drug = await context.entities.Drug.findUnique({
    where: { name: args.drug }
  });

  if (drug.isPrescribed === false) { throw new HttpError(403, 'This drug requires prescription.') };

  return context.entities.Order.create({
    data: {
      drug: args.drug,
      quantity: args.quantity,
      deliveryStatus: 'Pending',
      userId: context.user.id
    }
  });
}

export const updateDeliveryStatus = async (args, context) => {
 if (!context.user) { throw new HttpError(401) };
 const order = await context.entities.Order.findUnique({
   where: { id: args.orderId }
 });
 if (order.userId !== context.user.id) { throw new HttpError(403) };
 return context.entities.Order.update({
   where: { id: args.orderId },
   data: { deliveryStatus: args.status }
 });
}